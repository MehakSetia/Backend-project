// const express = require("express");
// const fs = require("fs");
// const path = require("path");
// const router = express.Router();

// const logEvent = (message) => {
//     const logMessage = `[${new Date().toISOString()}] - ${message}\n`;
//     fs.appendFileSync(path.join(__dirname, "../data.txt"), logMessage, "utf8");
// };



// router.get("/files/readfile", (req, res) => {
//     logEvent("File Read Request: data.txt");

//     const filePath = path.join(__dirname, "../data.txt");

//     if (!fs.existsSync(filePath)) {
//         return res.status(404).send("File not found");
//     }

//     const readStream = fs.createReadStream(filePath);
//     res.setHeader("Content-Type", "text/plain");
//     readStream.pipe(res);

// // router.get("/readfile", (req, res) => {
// //     const filePath = path.join(__dirname, "../data.txt");
    
// //     if (!fs.existsSync(filePath)) {
// //         return res.status(404).send("File not found");
// //     }

// //     const readStream = fs.createReadStream(filePath);
// //     readStream.on("error", (err) => {
// //         console.error("File read error:", err);
// //         res.status(500).send("Error reading file");
// //     });
// //     res.setHeader("Content-Type", "text/plain");
// //     readStream.pipe(res);
// });

// // Error Handling Route (Invalid Requests)
// router.use((req, res) => {
//     res.status(404).json({ error: "Route not found" });
// });

// module.exports = router;



const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();

// Log Event Function
const logEvent = (message) => {
    const logMessage = `[${new Date().toISOString()}] - ${message}\n`;
    fs.appendFileSync(path.join(__dirname, "../data.txt"), logMessage, "utf8");
};

// GET Endpoint to Read the File and Log the Event
router.get("/files/readfile", (req, res) => {
    logEvent("File Read Request: data.txt");

    const filePath = path.join(__dirname, "../data.txt");

    if (!fs.existsSync(filePath)) {
        return res.status(404).send("File not found");
    }

    const readStream = fs.createReadStream(filePath);
    res.setHeader("Content-Type", "text/plain");
    readStream.pipe(res);
});

// POST Endpoint to Log Custom Messages
router.post("/log-event", (req, res) => {
    const { message } = req.body; // Extract message from request body

    if (!message) {
        return res.status(400).json({ error: "Message is required" });
    }

    logEvent(message); // Log the custom message
    res.status(200).json({ success: "Event logged successfully" });
});

// Error Handling Route (Invalid Requests)
router.use((req, res) => {
    res.status(404).json({ error: "Route not found" });
});

module.exports = router;

