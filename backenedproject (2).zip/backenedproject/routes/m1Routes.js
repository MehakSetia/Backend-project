const express = require("express");
const fs = require("fs");
const path = require("path");

const router = express.Router();
const usersFile = path.join(__dirname, "../middlewares/data/users.json");

// Load users from file (if exists)
const loadUsers = () => {
    if (fs.existsSync(usersFile)) {
        return JSON.parse(fs.readFileSync(usersFile, "utf8"));

    }
    return [];
};

// Save users to file
const saveUsers = (users) => {
    
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2), "utf8");
    
};

// ✅ Register User (Stores in users.json)
router.post("/register", (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ error: "All fields are required" });
    }

    let users = loadUsers();

    // Check if user already exists
    if (users.some(user => user.email === email)) {
        return res.status(400).json({ error: "User already exists" });
    }

    const newUser = { id: users.length + 1, name, email, password };
    users.push(newUser);
    saveUsers(users);

    res.status(201).json({ message: "User registered successfully", user: { id: newUser.id, name, email } });
});

// ✅ Login User (Checks if user exists)
router.post("/login", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    let users = loadUsers();
    const user = users.find(user => user.email === email && user.password === password);

    if (!user) {
        return res.status(401).json({ error: "Invalid email or password" });
    }

    res.json({ message: "Login successful", user: { id: user.id, name: user.name, email: user.email } });
});

// ✅ Get All Users
router.get("/users", (req, res) => {
    const users = loadUsers();
    res.json(users);
});

module.exports = router;
