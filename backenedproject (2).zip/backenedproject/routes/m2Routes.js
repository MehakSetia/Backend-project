const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();

const usersFile = path.join(__dirname, "../middlewares/data/users.json");

// Function to load users from file
const loadUsers = () => {
    if (fs.existsSync(usersFile)) {
        return JSON.parse(fs.readFileSync(usersFile, "utf8"));
    }
    return [];
};

// Function to save users to file
const saveUsers = (users) => {
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2), "utf8");
};

// ✅ Get All Users (Reads from `users.json`)
router.get("/users", (req, res) => {
    const users = loadUsers();
    res.json(users);
});

// ✅ Update User (Updates `users.json`)
router.put("/update/:id", (req, res) => {
    const userId = parseInt(req.params.id);
    const { name, email } = req.body;

    let users = loadUsers();
    let user = users.find(u => u.id === userId);

    if (!user) return res.status(404).json({ error: "User not found" });

    user.name = name || user.name;
    user.email = email || user.email;

    saveUsers(users);

    res.json({ message: "User updated successfully", user });
});

module.exports = router;
