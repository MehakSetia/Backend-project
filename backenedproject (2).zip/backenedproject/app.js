const express = require("express");
const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Import Routes
const member1Routes = require("./routes/m1Routes");
const member2Routes = require("./routes/m2Routes");
const member3Routes = require("./routes/m3Routes");

// Use Routes
app.use("/api/auth", member1Routes);
app.use("/api/users", member2Routes);
app.use("/api", member3Routes);

// Error Handling Middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: "Internal Server Error" });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
